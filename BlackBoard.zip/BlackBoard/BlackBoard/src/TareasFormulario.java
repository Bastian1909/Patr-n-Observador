// Importación de librerías necesarias
import javax.swing.*; // Para la interfaz gráfica
import java.awt.*; // Para diseño de componentes
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener; // Para manejar eventos
import java.sql.*; // Para conexión con la base de datos SQLite
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

// Clase principal que extiende JFrame (ventana de Swing)
public class TareasFormulario extends JFrame {
    private Connection connection; // Conexión a la base de datos
    private GestorDeTareas gestor; // Objeto que usa estrategia para manipular tareas

    // Constructor de la clase
    public TareasFormulario() {
        conectarBaseDeDatos(); // Conexión a la base de datos
        gestor = new GestorDeTareas(); // Inicialización del gestor

        setTitle("Gestor de Tareas - Formulario"); // Título de la ventana
        setSize(500, 500); // Tamaño de la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cierre al salir
        setLayout(new GridLayout(8, 2, 10, 10)); // Diseño con rejilla de 8 filas y 2 columnas

        // Creación de etiquetas y campos de texto
        JLabel nombreLabel = new JLabel("Nombre:");
        JTextField nombreField = new JTextField();

        JLabel prioridadLabel = new JLabel("Prioridad (1-Alta, 2-Media, 3-Baja):");
        JTextField prioridadField = new JTextField();

        JLabel estadoLabel = new JLabel("Estado:");
        JTextField estadoField = new JTextField();

        JLabel fechaEntregaLabel = new JLabel("Fecha de Entrega (DD-MM-YY):");
        JTextField fechaEntregaField = new JTextField();

        // Botones de acción
        JButton guardarButton = new JButton("Guardar Tarea");
        JButton actualizarButton = new JButton("Actualizar Tarea");
        JButton mostrarButton = new JButton("Mostrar Tareas");
        JButton ordenarButton = new JButton("Ordenar por Prioridad");

        // Agregado de componentes al formulario
        add(nombreLabel); add(nombreField);
        add(prioridadLabel); add(prioridadField);
        add(estadoLabel); add(estadoField);
        add(fechaEntregaLabel); add(fechaEntregaField);
        add(guardarButton); add(actualizarButton);
        add(mostrarButton); add(ordenarButton);

        // Acción del botón Guardar
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Obtención de datos del formulario
                    String nombre = nombreField.getText();
                    int prioridad = Integer.parseInt(prioridadField.getText());
                    String estado = estadoField.getText();
                    String fechaEntrega = fechaEntregaField.getText();

                    // Creación de objeto Tarea
                    Tarea tarea = new Tarea(nombre, prioridad, estado, fechaEntrega);
                    gestor.setEstrategia(new GuardarTarea()); // Selección de estrategia
                    gestor.ejecutarEstrategia(connection, tarea); // Ejecución

                    // Confirmación al usuario
                    JOptionPane.showMessageDialog(null, "Tarea guardada correctamente:\n" +
                            "Nombre: " + nombre +
                            "\nPrioridad: " + traducirPrioridad(prioridad) +
                            "\nEstado: " + estado +
                            "\nFecha de entrega: " + fechaEntrega);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al guardar la tarea.");
                }
            }
        });

        // Acción del botón Actualizar
        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    // Solicitud de datos al usuario
                    String nombre = JOptionPane.showInputDialog("Ingrese el Nombre de la tarea a actualizar:");
                    String nuevoEstado = JOptionPane.showInputDialog("Ingrese el nuevo estado:");
                    int nuevaPrioridad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la nueva prioridad (1-Alta, 2-Media, 3-Baja):"));

                    // Creación del objeto Tarea para actualización
                    Tarea tarea = new Tarea(nombre, nuevaPrioridad, nuevoEstado, null);
                    gestor.setEstrategia(new ActualizarTarea()); // Selección de estrategia
                    gestor.ejecutarEstrategia(connection, tarea); // Ejecución

                    // Recuperación de la fecha de entrega
                    String fechaEntrega = obtenerFechaEntrega(nombre);

                    // Confirmación al usuario
                    JOptionPane.showMessageDialog(null, "Tarea actualizada correctamente:\n" +
                            "Nombre: " + nombre +
                            "\nNuevo Estado: " + nuevoEstado +
                            "\nNueva Prioridad: " + traducirPrioridad(nuevaPrioridad) +
                            "\nFecha de entrega: " + fechaEntrega);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al actualizar la tarea.");
                }
            }
        });

        // Acciones para mostrar tareas
        mostrarButton.addActionListener(e -> mostrarTareas(false)); // Muestra en orden natural
        ordenarButton.addActionListener(e -> mostrarTareas(true)); // Muestra ordenado por prioridad

        setVisible(true); // Hace visible la ventana
    }

    // Método para conectar a la base de datos SQLite
    private void conectarBaseDeDatos() {
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:tareas.db"); // Conexión
            Statement stmt = connection.createStatement();
            // Creación de la tabla si no existe
            String sql = "CREATE TABLE IF NOT EXISTS tareas (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "nombre TEXT NOT NULL, " +
                    "prioridad INTEGER NOT NULL, " +
                    "estado TEXT NOT NULL, " +
                    "fechaEntrega TEXT NOT NULL)";
            stmt.execute(sql);
        } catch (Exception e) {
            System.out.println("Error al conectar a la base de datos.");
        }
    }

    // Método para obtener la fecha de entrega de una tarea por su nombre
    private String obtenerFechaEntrega(String nombre) {
        String sql = "SELECT fechaEntrega FROM tareas WHERE nombre = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("fechaEntrega");
            }
        } catch (Exception e) {
            System.out.println("Error al obtener la fecha de entrega.");
        }
        return null;
    }

    // Método para mostrar las tareas, con opción de ordenarlas por prioridad
    private void mostrarTareas(boolean ordenar) {
        List<Tarea> listaTareas = new ArrayList<>();

        try {
            String sql = "SELECT * FROM tareas";
            try (PreparedStatement stmt = connection.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    listaTareas.add(new Tarea(
                            rs.getString("nombre"),
                            rs.getInt("prioridad"),
                            rs.getString("estado"),
                            rs.getString("fechaEntrega")
                    ));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener tareas: " + e.getMessage());
            return;
        }

        if (listaTareas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay tareas para mostrar.");
            return;
        }

        if (ordenar) {
            listaTareas.sort(Comparator.comparingInt(Tarea::getPrioridad)); // Ordena por prioridad
        }

        // Construcción del texto para mostrar en cuadro de diálogo
        StringBuilder resultado = new StringBuilder();
        for (Tarea t : listaTareas) {
            resultado.append("Nombre: ").append(t.getNombre())
                    .append(", Prioridad: ").append(traducirPrioridad(t.getPrioridad()))
                    .append(", Estado: ").append(t.getEstado())
                    .append(", Fecha de Entrega: ").append(t.getFechaEntrega())
                    .append("\n");
        }

        // Muestra de tareas en un JTextArea dentro de un JScrollPane
        JTextArea areaTexto = new JTextArea(resultado.toString());
        areaTexto.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaTexto);
        scroll.setPreferredSize(new Dimension(400, 300));
        String titulo = ordenar ? "Tareas ordenadas por prioridad" : "Tareas en su estado original";
        JOptionPane.showMessageDialog(null, scroll, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    // Método auxiliar para traducir prioridad de número a texto
    private String traducirPrioridad(int prioridad) {
        return switch (prioridad) {
            case 1 -> "Alta";
            case 2 -> "Media";
            case 3 -> "Baja";
            default -> "Desconocida";
        };
    }

    // Método principal para ejecutar el formulario
    public static void main(String[] args) {
        new TareasFormulario();
    }
}

