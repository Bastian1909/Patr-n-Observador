import java.sql.Connection;

public class GestorDeTareas {
    private EstrategiaTarea estrategia;

    public void setEstrategia(EstrategiaTarea estrategia) {
        this.estrategia = estrategia;
    }

    public void ejecutarEstrategia(Connection connection, Tarea tarea) throws Exception {
        if (estrategia != null) {
            estrategia.ejecutar(connection, tarea);
        } else {
            throw new IllegalStateException("No se ha definido una estrategia.");
        }
    }
}