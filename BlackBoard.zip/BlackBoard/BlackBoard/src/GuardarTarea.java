import java.sql.Connection;
import java.sql.PreparedStatement;

public class GuardarTarea implements EstrategiaTarea {
    @Override
    public void ejecutar(Connection connection, Tarea tarea) throws Exception {
        String sql = "INSERT INTO tareas (nombre, prioridad, estado, fechaEntrega) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, tarea.getNombre());
            pstmt.setInt(2, tarea.getPrioridad());
            pstmt.setString(3, tarea.getEstado());
            pstmt.setString(4, tarea.getFechaEntrega());
            pstmt.executeUpdate();
        }
    }
}