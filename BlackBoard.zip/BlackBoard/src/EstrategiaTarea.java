import java.sql.Connection;

public interface EstrategiaTarea {
    void ejecutar(Connection connection, Tarea tarea) throws Exception;
}