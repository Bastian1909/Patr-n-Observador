import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ObtenerFechaEntrega implements EstrategiaTarea {
    private String fechaEntrega;

    @Override
    public void ejecutar(Connection connection, Tarea tarea) throws Exception {
        String sql = "SELECT fechaEntrega FROM tareas WHERE nombre = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, tarea.getNombre());
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                fechaEntrega = rs.getString("fechaEntrega");
            }
        }
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }
}