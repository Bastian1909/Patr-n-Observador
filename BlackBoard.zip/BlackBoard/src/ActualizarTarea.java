import java.sql.Connection;
import java.sql.PreparedStatement;

public class ActualizarTarea implements EstrategiaTarea {
    @Override
    public void ejecutar(Connection connection, Tarea tarea) throws Exception {
        String sql = "UPDATE tareas SET estado = ?, prioridad = ? WHERE nombre = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, tarea.getEstado());
            pstmt.setInt(2, tarea.getPrioridad());
            pstmt.setString(3, tarea.getNombre());
            pstmt.executeUpdate();
        }
    }
}