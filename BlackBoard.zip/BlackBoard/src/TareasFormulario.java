import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

// Asegúrate de importar las clases necesarias
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TareasFormulario extends JFrame {
    private Connection connection;
    private GestorDeTareas gestor;

    public TareasFormulario() {
        // Conectar a la base de datos SQLite
        conectarBaseDeDatos();

        gestor = new GestorDeTareas();

        setTitle("Gestor de Tareas - Formulario");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(6, 2, 10, 10)); // Diseño estilo formulario

        // Campos del formulario
        JLabel nombreLabel = new JLabel("Nombre:");
        JTextField nombreField = new JTextField();

        JLabel prioridadLabel = new JLabel("Prioridad:");
        JTextField prioridadField = new JTextField();

        JLabel estadoLabel = new JLabel("Estado:");
        JTextField estadoField = new JTextField();

        JLabel fechaEntregaLabel = new JLabel("Fecha de Entrega (DD-MM-YY):");
        JTextField fechaEntregaField = new JTextField();

        JButton guardarButton = new JButton("Guardar Tarea");
        JButton actualizarButton = new JButton("Actualizar Tarea");

        // Agregar componentes al formulario
        add(nombreLabel);
        add(nombreField);
        add(prioridadLabel);
        add(prioridadField);
        add(estadoLabel);
        add(estadoField);
        add(fechaEntregaLabel);
        add(fechaEntregaField);
        add(guardarButton);
        add(actualizarButton);

        // Acción del botón guardar
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String nombre = nombreField.getText();
                    int prioridad = Integer.parseInt(prioridadField.getText());
                    String estado = estadoField.getText();
                    String fechaEntrega = fechaEntregaField.getText();

                    Tarea tarea = new Tarea(nombre, prioridad, estado, fechaEntrega);
                    gestor.setEstrategia(new GuardarTarea());
                    gestor.ejecutarEstrategia(connection, tarea);

                    // Notificación con los datos guardados
                    JOptionPane.showMessageDialog(null, "Tarea guardada correctamente:\n" +
                            "Nombre: " + nombre + "\nPrioridad: " + prioridad + "\nEstado: " + estado + "\nFecha de entrega: " + fechaEntrega);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al guardar la tarea.");
                }
            }
        });

        // Acción del botón actualizar
        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String nombre = JOptionPane.showInputDialog("Ingrese el Nombre de la tarea a actualizar:");
                    String nuevoEstado = JOptionPane.showInputDialog("Ingrese el nuevo estado:");
                    int nuevaPrioridad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la nueva prioridad:"));

                    Tarea tarea = new Tarea(nombre, nuevaPrioridad, nuevoEstado, null);
                    gestor.setEstrategia(new ActualizarTarea());
                    gestor.ejecutarEstrategia(connection, tarea);

                    // Obtener la fecha de entrega actualizada
                    String fechaEntrega = obtenerFechaEntrega(nombre);

                    // Notificación con los datos actualizados
                    JOptionPane.showMessageDialog(null, "Tarea actualizada correctamente:\n" +
                            "Nombre: " + nombre + "\nNuevo Estado: " + nuevoEstado + "\nNueva Prioridad: " + nuevaPrioridad + "\nFecha de entrega: " + fechaEntrega);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al actualizar la tarea.");
                }
            }
        });

        setVisible(true);
    }

    private void conectarBaseDeDatos() {
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:tareas.db");
            Statement stmt = connection.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS tareas (" +
                         "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                         "nombre TEXT NOT NULL, " +
                         "prioridad INTEGER NOT NULL, " +
                         "estado TEXT NOT NULL, " +
                         "fechaEntrega TEXT NOT NULL)";
            stmt.execute(sql);
        } catch (Exception e) {
            System.out.println("Error al conectar a la base de datos.");
        }
    }

    private String obtenerFechaEntrega(String nombre) {
        String sql = "SELECT fechaEntrega FROM tareas WHERE nombre = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("fechaEntrega");
            }
        } catch (Exception e) {
            System.out.println("Error al obtener la fecha de entrega.");
        }
        return null;
    }

    public static void main(String[] args) {
        new TareasFormulario();
    }
}