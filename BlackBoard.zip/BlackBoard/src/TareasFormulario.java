import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TareasFormulario extends JFrame {
    private Connection connection;
    private GestorDeTareas gestor;

    public TareasFormulario() {
        // Conectar a la base de datos SQLite
        conectarBaseDeDatos();

        gestor = new GestorDeTareas();

        setTitle("Gestor de Tareas - Formulario");
        setSize(500, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(8, 2, 10, 10)); // Diseño estilo formulario

        // Campos del formulario
        JLabel nombreLabel = new JLabel("Nombre:");
        JTextField nombreField = new JTextField();

        JLabel prioridadLabel = new JLabel("Prioridad:");
        JTextField prioridadField = new JTextField();

        JLabel estadoLabel = new JLabel("Estado:");
        JTextField estadoField = new JTextField();

        JLabel fechaEntregaLabel = new JLabel("Fecha de Entrega (DD-MM-YY):");
        JTextField fechaEntregaField = new JTextField();

        JButton guardarButton = new JButton("Guardar Tarea");
        JButton actualizarButton = new JButton("Actualizar Tarea");
        JButton mostrarButton = new JButton("Mostrar Tareas");
        JButton ordenarButton = new JButton("Ordenar por Prioridad");

        // Agregar componentes al formulario
        add(nombreLabel);
        add(nombreField);
        add(prioridadLabel);
        add(prioridadField);
        add(estadoLabel);
        add(estadoField);
        add(fechaEntregaLabel);
        add(fechaEntregaField);
        add(guardarButton);
        add(actualizarButton);
        add(mostrarButton);
        add(ordenarButton);

        // Acción del botón guardar
        guardarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String nombre = nombreField.getText();
                    int prioridad = Integer.parseInt(prioridadField.getText());
                    String estado = estadoField.getText();
                    String fechaEntrega = fechaEntregaField.getText();

                    Tarea tarea = new Tarea(nombre, prioridad, estado, fechaEntrega);
                    gestor.setEstrategia(new GuardarTarea());
                    gestor.ejecutarEstrategia(connection, tarea);

                    // Notificación con los datos guardados
                    JOptionPane.showMessageDialog(null, "Tarea guardada correctamente:\n" +
                            "Nombre: " + nombre + "\nPrioridad: " + prioridad + "\nEstado: " + estado + "\nFecha de entrega: " + fechaEntrega);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al guardar la tarea.");
                }
            }
        });

        // Acción del botón actualizar
        actualizarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String nombre = JOptionPane.showInputDialog("Ingrese el Nombre de la tarea a actualizar:");
                    String nuevoEstado = JOptionPane.showInputDialog("Ingrese el nuevo estado:");
                    int nuevaPrioridad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la nueva prioridad:"));

                    Tarea tarea = new Tarea(nombre, nuevaPrioridad, nuevoEstado, null);
                    gestor.setEstrategia(new ActualizarTarea());
                    gestor.ejecutarEstrategia(connection, tarea);

                    // Obtener la fecha de entrega actualizada
                    String fechaEntrega = obtenerFechaEntrega(nombre);

                    // Notificación con los datos actualizados
                    JOptionPane.showMessageDialog(null, "Tarea actualizada correctamente:\n" +
                            "Nombre: " + nombre + "\nNuevo Estado: " + nuevoEstado + "\nNueva Prioridad: " + nuevaPrioridad + "\nFecha de entrega: " + fechaEntrega);
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(null, "Error al actualizar la tarea.");
                }
            }
        });

        // Acción del botón mostrar
        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarTareas(false); // Mostrar las tareas en su estado original
            }
        });

        // Acción del botón ordenar
        ordenarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarTareas(true); // Mostrar las tareas ordenadas por prioridad
            }
        });

        setVisible(true);
    }

    private void conectarBaseDeDatos() {
        try {
            connection = DriverManager.getConnection("jdbc:sqlite:tareas.db");
            Statement stmt = connection.createStatement();
            String sql = "CREATE TABLE IF NOT EXISTS tareas (" +
                         "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                         "nombre TEXT NOT NULL, " +
                         "prioridad INTEGER NOT NULL, " +
                         "estado TEXT NOT NULL, " +
                         "fechaEntrega TEXT NOT NULL)";
            stmt.execute(sql);
        } catch (Exception e) {
            System.out.println("Error al conectar a la base de datos.");
        }
    }

    private String obtenerFechaEntrega(String nombre) {
        String sql = "SELECT fechaEntrega FROM tareas WHERE nombre = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getString("fechaEntrega");
            }
        } catch (Exception e) {
            System.out.println("Error al obtener la fecha de entrega.");
        }
        return null;
    }

    private void mostrarTareas(boolean ordenar) {
        List<Tarea> listaTareas = new ArrayList<>();

        try {
            String sql = "SELECT * FROM tareas";
            try (PreparedStatement stmt = connection.prepareStatement(sql);
                 ResultSet rs = stmt.executeQuery()) {

                while (rs.next()) {
                    listaTareas.add(new Tarea(
                            rs.getString("nombre"),
                            rs.getInt("prioridad"),
                            rs.getString("estado"),
                            rs.getString("fechaEntrega")
                    ));
                }
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al obtener tareas: " + e.getMessage());
            return;
        }

        if (listaTareas.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No hay tareas para mostrar.");
            return;
        }

        // Ordenar las tareas por prioridad si se solicita
        if (ordenar) {
            listaTareas.sort(Comparator.comparingInt(Tarea::getPrioridad));
        }

        // Mostrar las tareas en un cuadro de diálogo
        StringBuilder resultado = new StringBuilder();
        for (Tarea t : listaTareas) {
            resultado.append("Nombre: ").append(t.getNombre())
                    .append(", Prioridad: ").append(t.getPrioridad())
                    .append(", Estado: ").append(t.getEstado())
                    .append(", Fecha de Entrega: ").append(t.getFechaEntrega())
                    .append("\n");
        }

        JTextArea areaTexto = new JTextArea(resultado.toString());
        areaTexto.setEditable(false);
        JScrollPane scroll = new JScrollPane(areaTexto);
        scroll.setPreferredSize(new Dimension(400, 300));
        String titulo = ordenar ? "Tareas ordenadas por prioridad" : "Tareas en su estado original";
        JOptionPane.showMessageDialog(null, scroll, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        new TareasFormulario();
    }
}