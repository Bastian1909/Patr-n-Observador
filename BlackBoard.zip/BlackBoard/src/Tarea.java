public class Tarea {
    private String nombre;
    private int prioridad;
    private String estado;
    private String fechaEntrega;

    public Tarea(String nombre, int prioridad, String estado, String fechaEntrega) {
        this.nombre = nombre;
        this.prioridad = prioridad;
        this.estado = estado;
        this.fechaEntrega = fechaEntrega;
    }

    public String getNombre() {
        return nombre;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public String getEstado() {
        return estado;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }
}